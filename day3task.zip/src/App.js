
import './App.css';
import CounterClass1 from './componentsCounter/CounterClass1';
import Employee from './Employee';

function App() {
  return (
    <div className="App">
      <Employee/>

      <CounterClass1/>
    </div>
  );
}

export default App;
